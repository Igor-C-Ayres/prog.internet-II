// server.js
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

// Array para armazenar os usuários (iniciando com um usuário Admin)
let users = [
    { id: 1, name: 'Admin', email: 'admin@example.com', isAdmin: true }
];

// Configurações
app.set('view engine', 'ejs');  // Definindo o EJS como engine de visualização
app.set('views', path.join(__dirname, 'views'));  // Definindo o diretório das views

app.use(bodyParser.urlencoded({ extended: true }));  // Middleware para processar dados dos formulários

// Rota principal - Lista de usuários
app.get('/', (req, res) => {
    res.render('users/list', { users });
});

// Rota para mostrar formulário de criação
app.get('/create', (req, res) => {
    res.render('users/create', { error: null });
});

// Rota para criar usuário
app.post('/create', (req, res) => {
    const { name, email } = req.body;
    const isAdmin = req.body.isAdmin === 'on';  // Verifica se o checkbox de admin está marcado

    // Validação simples para nome e email
    if (!name || !email) {
        return res.render('users/create', { 
            error: 'Nome e email são obrigatórios' 
        });
    }

    // Criando um novo usuário com ID incremental
    const newUser = {
        id: users.length + 1,
        name,
        email,
        isAdmin
    };

    users.push(newUser);  // Adiciona o novo usuário ao array de usuários
    res.redirect('/');  // Redireciona para a lista de usuários
});

// Rota para deletar usuário
app.post('/delete/:id', (req, res) => {
    const id = parseInt(req.params.id);  // Obtém o ID do usuário a partir da rota
    users = users.filter(user => user.id !== id);  // Remove o usuário do array
    res.redirect('/');  // Redireciona para a lista de usuários
});

// Inicia o servidor na porta 3000
app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});
